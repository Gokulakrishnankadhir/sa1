package com.project.models;

import java.util.Date;

public class RegistrationModel {
    private int id;
    private int userId; // ID of the student registering
    private int eventId; // ID of the event
    private Date registrationDate;
    private String approvalStatus; // "pending" or "approved"

    // Constructor
    public RegistrationModel(int id, int userId, int eventId, Date registrationDate, String approvalStatus) {
        this.id = id;
        this.userId = userId;
        this.eventId = eventId;
        this.registrationDate = registrationDate;
        this.approvalStatus = approvalStatus;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getEventId() {
        return eventId;
    }

    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    public Date getRegistrationDate() {
        return registrationDate;
    }

    public void setRegistrationDate(Date registrationDate) {
        this.registrationDate = registrationDate;
    }

    public String getApprovalStatus() {
        return approvalStatus;
    }

    public void setApprovalStatus(String approvalStatus) {
        this.approvalStatus = approvalStatus;
    }

    @Override
    public String toString() {
        return "RegistrationModel{" +
                "id=" + id +
                ", userId=" + userId +
                ", eventId=" + eventId +
                ", registrationDate=" + registrationDate +
                ", approvalStatus='" + approvalStatus + '\'' +
                '}';
    }
}
