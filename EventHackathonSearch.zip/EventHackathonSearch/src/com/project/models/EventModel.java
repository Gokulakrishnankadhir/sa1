package com.project.models;

import java.util.Date;

public class EventModel {
    private int id;
    private String eventName;
    private String eventDescription;
    private Date eventDate;
    private String location;
    private String college;
    private int createdBy; // ID of the user (organizer/admin) who created the event
    private String approvalStatus; // "pending" or "approved"

    // Constructor
    public EventModel(int id, String eventName, String eventDescription, Date eventDate, String location, 
                      String college, int createdBy, String approvalStatus) {
        this.id = id;
        this.eventName = eventName;
        this.eventDescription = eventDescription;
        this.eventDate = eventDate;
        this.location = location;
        this.college = college;
        this.createdBy = createdBy;
        this.approvalStatus = approvalStatus;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public String getEventDescription() {
        return eventDescription;
    }

    public void setEventDescription(String eventDescription) {
        this.eventDescription = eventDescription;
    }

    public Date getEventDate() {
        return eventDate;
    }

    public void setEventDate(Date eventDate) {
        this.eventDate = eventDate;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getCollege() {
        return college;
    }

    public void setCollege(String college) {
        this.college = college;
    }

    public int getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(int createdBy) {
        this.createdBy = createdBy;
    }

    public String getApprovalStatus() {
        return approvalStatus;
    }

    public void setApprovalStatus(String approvalStatus) {
        this.approvalStatus = approvalStatus;
    }

    @Override
    public String toString() {
        return "EventModel{" +
                "id=" + id +
                ", eventName='" + eventName + '\'' +
                ", eventDate=" + eventDate +
                ", location='" + location + '\'' +
                ", college='" + college + '\'' +
                ", approvalStatus='" + approvalStatus + '\'' +
                '}';
    }
}
