package com.project;

import com.project.auth.LoginPage;

public class Main {
    public static void main(String[] args) {
        new LoginPage();  // Start the application at the Login page
    }
}
