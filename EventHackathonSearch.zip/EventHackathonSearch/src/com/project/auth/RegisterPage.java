package com.project.auth;

import com.project.utils.DBConnection;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.*;

public class RegisterPage extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JTextField emailField;
    private JComboBox<String> roleComboBox;
    private JTextField collegeField;
    private JButton registerButton;

    public RegisterPage() {
        setTitle("Register");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);

        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setBounds(20, 20, 100, 25);
        add(usernameLabel);

        usernameField = new JTextField();
        usernameField.setBounds(130, 20, 200, 25);
        add(usernameField);

        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setBounds(20, 60, 100, 25);
        add(passwordLabel);

        passwordField = new JPasswordField();
        passwordField.setBounds(130, 60, 200, 25);
        add(passwordField);

        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setBounds(20, 100, 100, 25);
        add(emailLabel);

        emailField = new JTextField();
        emailField.setBounds(130, 100, 200, 25);
        add(emailField);

        JLabel roleLabel = new JLabel("Role:");
        roleLabel.setBounds(20, 140, 100, 25);
        add(roleLabel);

        roleComboBox = new JComboBox<>(new String[]{"student", "organizer"});
        roleComboBox.setBounds(130, 140, 200, 25);
        add(roleComboBox);

        JLabel collegeLabel = new JLabel("College:");
        collegeLabel.setBounds(20, 180, 100, 25);
        add(collegeLabel);

        collegeField = new JTextField();
        collegeField.setBounds(130, 180, 200, 25);
        add(collegeField);

        registerButton = new JButton("Register");
        registerButton.setBounds(130, 220, 100, 25);
        add(registerButton);

        registerButton.addActionListener(new RegisterAction());

        setVisible(true);
    }

    private class RegisterAction implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());
            String email = emailField.getText();
            String role = (String) roleComboBox.getSelectedItem();
            String college = collegeField.getText();
            String approvalStatus = role.equals("organizer") ? "pending" : "approved";

            try (Connection conn = DBConnection.getConnection()) {
                String query = "INSERT INTO users (username, password, role, college, email, approval_status) VALUES (?, ?, ?, ?, ?, ?)";
                PreparedStatement stmt = conn.prepareStatement(query);
                stmt.setString(1, username);
                stmt.setString(2, password);
                stmt.setString(3, role);
                stmt.setString(4, college);
                stmt.setString(5, email);
                stmt.setString(6, approvalStatus);

                int rowsInserted = stmt.executeUpdate();
                if (rowsInserted > 0) {
                    JOptionPane.showMessageDialog(null, "Registration successful! Await admin approval if you registered as an organizer.");
                    dispose();
                    new LoginPage();  // Redirect to login page after registration
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error in registration.");
            }
        }
    }

    public static void main(String[] args) {
        new RegisterPage();
    }
}
