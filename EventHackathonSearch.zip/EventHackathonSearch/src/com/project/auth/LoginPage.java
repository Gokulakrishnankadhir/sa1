package com.project.auth;

import com.project.dashboard.AdminDashboard;
import com.project.dashboard.OrganizerDashboard;
import com.project.dashboard.StudentDashboard;
import com.project.utils.DBConnection;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LoginPage extends JFrame {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;

    public LoginPage() {
        setTitle("Login");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new FlowLayout());

        // Username input
        add(new JLabel("Username:"));
        usernameField = new JTextField(15);
        add(usernameField);

        // Password input
        add(new JLabel("Password:"));
        passwordField = new JPasswordField(15);
        add(passwordField);

        // Login button
        loginButton = new JButton("Login");
        add(loginButton);

        loginButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());
                authenticateUser(username, password);
            }
        });

        setVisible(true);
    }

    private void authenticateUser(String username, String password) {
        try (Connection conn = DBConnection.getConnection()) {
            String query = "SELECT * FROM users WHERE username = ? AND password = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, username);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                String role = rs.getString("role");
                String approvalStatus = rs.getString("approval_status");

                if ("organizer".equals(role) && !"approved".equals(approvalStatus)) {
                    JOptionPane.showMessageDialog(null, "Your account is pending approval.");
                } else {
                    openDashboard(role, rs.getString("college"));
                    dispose(); // Close login page after successful login
                }
            } else {
                JOptionPane.showMessageDialog(null, "Invalid username or password.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error connecting to database.");
        }
    }

    private void openDashboard(String role, String college) {
        switch (role) {
            case "admin":
                new AdminDashboard();
                break;
            case "organizer":
                new OrganizerDashboard(college);
                break;
            case "student":
                new StudentDashboard(college);
                break;
            default:
                JOptionPane.showMessageDialog(null, "Unknown user role.");
                break;
        }
    }

    public static void main(String[] args) {
        new LoginPage();
    }
}
