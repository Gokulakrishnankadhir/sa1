package com.project.services;

import com.project.utils.DBConnection;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.util.Vector;

public class RegistrationService {

    // Retrieve pending registrations for a specific college
    public static DefaultTableModel getPendingRegistrations(String college) {
        DefaultTableModel model = new DefaultTableModel(new String[]{"Registration ID", "Event Name", "Student Name", "Status"}, 0);
        try (Connection conn = DBConnection.getConnection()) {
            String query = "SELECT r.id, e.event_name, u.username, r.approval_status " +
                           "FROM registrations r " +
                           "JOIN users u ON r.user_id = u.id " +
                           "JOIN events e ON r.event_id = e.id " +
                           "WHERE u.college = ? AND r.approval_status = 'pending'";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, college);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                Vector<Object> row = new Vector<>();
                row.add(rs.getInt("id"));
                row.add(rs.getString("event_name"));
                row.add(rs.getString("username"));
                row.add(rs.getString("approval_status"));
                model.addRow(row);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return model;
    }

    // Update registration status
    public static void updateRegistrationStatus(int registrationId, String status) {
        try (Connection conn = DBConnection.getConnection()) {
            String query = "UPDATE registrations SET approval_status = ? WHERE id = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, status);
            stmt.setInt(2, registrationId);

            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Registration status updated successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error updating registration status.");
        }
    }
}
