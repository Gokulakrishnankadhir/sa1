package com.project.services;

import com.project.utils.DBConnection;
import java.sql.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class EventService {

    // Retrieve events based on role and campus preference
    public static DefaultTableModel getEvents(String role, String college, boolean inCampusOnly) {
        DefaultTableModel model = new DefaultTableModel(new String[]{"ID", "Name", "Description", "Date", "Location", "College"}, 0);
        try (Connection conn = DBConnection.getConnection()) {
            String query = "SELECT * FROM events";
            if ("student".equals(role)) {
                query += inCampusOnly ? " WHERE college = ?" : " WHERE college != ?";
            } else if ("organizer".equals(role)) {
                query += " WHERE college = ?";
            }

            PreparedStatement stmt = conn.prepareStatement(query);
            if ("student".equals(role) || "organizer".equals(role)) {
                stmt.setString(1, college);
            }

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Vector<Object> row = new Vector<>();
                row.add(rs.getInt("id"));
                row.add(rs.getString("event_name"));
                row.add(rs.getString("event_description"));
                row.add(rs.getDate("event_date"));
                row.add(rs.getString("location"));
                row.add(rs.getString("college"));
                model.addRow(row);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return model;
    }

    // Add a new event
    public static void addEvent(String eventName, String description, Date date, String location, String college, int createdBy) {
        try (Connection conn = DBConnection.getConnection()) {
            String query = "INSERT INTO events (event_name, event_description, event_date, location, college, created_by) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, eventName);
            stmt.setString(2, description);
            stmt.setDate(3, date);
            stmt.setString(4, location);
            stmt.setString(5, college);
            stmt.setInt(6, createdBy);

            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Event added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error adding event.");
        }
    }

    // Update existing event details
    public static void updateEvent(int eventId, String eventName, String description, Date date, String location) {
        try (Connection conn = DBConnection.getConnection()) {
            String query = "UPDATE events SET event_name = ?, event_description = ?, event_date = ?, location = ? WHERE id = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, eventName);
            stmt.setString(2, description);
            stmt.setDate(3, date);
            stmt.setString(4, location);
            stmt.setInt(5, eventId);

            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Event updated successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error updating event.");
        }
    }

    // Delete an event
    public static void deleteEvent(int eventId) {
        try (Connection conn = DBConnection.getConnection()) {
            String query = "DELETE FROM events WHERE id = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, eventId);

            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null, "Event deleted successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error deleting event.");
        }
    }

    // Get event details for editing
    public static Map<String, Object> getEventById(int eventId) {
        Map<String, Object> eventDetails = new HashMap<>();
        try (Connection conn = DBConnection.getConnection()) {
            String query = "SELECT * FROM events WHERE id = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, eventId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                eventDetails.put("event_name", rs.getString("event_name"));
                eventDetails.put("event_description", rs.getString("event_description"));
                eventDetails.put("event_date", rs.getDate("event_date"));
                eventDetails.put("location", rs.getString("location"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return eventDetails;
    }
}
