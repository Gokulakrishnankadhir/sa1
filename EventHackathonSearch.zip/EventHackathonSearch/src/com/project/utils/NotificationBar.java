package com.project.utils;

import java.util.ArrayList;
import java.util.List;

public class NotificationBar {

    private List<String> notifications;

    // Constructor
    public NotificationBar() {
        notifications = new ArrayList<>();
    }

    // Method to add a notification message
    public void addNotification(String message) {
        notifications.add(message);
    }

    // Method to retrieve all notifications
    public List<String> getNotifications() {
        return notifications;
    }

    // Method to clear all notifications
    public void clearNotifications() {
        notifications.clear();
    }

    // Display notifications in the console for now
    public void displayNotifications() {
        System.out.println("Notifications:");
        for (String notification : notifications) {
            System.out.println("- " + notification);
        }
    }
}
