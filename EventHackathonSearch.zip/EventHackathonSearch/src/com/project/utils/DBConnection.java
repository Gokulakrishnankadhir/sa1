package com.project.utils;

import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBConnection {
    private static final String CONFIG_FILE_PATH = "resources/config.properties";

    private static String dbUrl;
    private static String dbUsername;
    private static String dbPassword;

    static {
        try {
            // Load the MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Load database properties from config file
            try (FileInputStream fis = new FileInputStream(CONFIG_FILE_PATH)) {
                Properties properties = new Properties();
                properties.load(fis);

                dbUrl = properties.getProperty("db.url");
                dbUsername = properties.getProperty("db.username");
                dbPassword = properties.getProperty("db.password");
            } catch (IOException e) {
                System.err.println("Error loading database configuration file.");
                e.printStackTrace();
            }

        } catch (ClassNotFoundException e) {
            System.err.println("Error loading JDBC Driver: " + e.getMessage());
        }
    }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(dbUrl, dbUsername, dbPassword);
    }
}
