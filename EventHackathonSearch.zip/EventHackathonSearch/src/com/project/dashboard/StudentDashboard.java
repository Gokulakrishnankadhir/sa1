package com.project.dashboard;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class StudentDashboard extends JFrame {
    private String college;
    private JButton viewInCampusEventsButton;
    private JButton viewOutsideCampusEventsButton;
    private JButton logoutButton;

    public StudentDashboard(String college) {
        this.college = college;

        setTitle("Student Dashboard");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new FlowLayout());

        viewInCampusEventsButton = new JButton("View In-Campus Events");
        viewOutsideCampusEventsButton = new JButton("View Outside-Campus Events");
        logoutButton = new JButton("Logout");

        viewInCampusEventsButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new ViewEventsPage("student", college, true);
            }
        });

        viewOutsideCampusEventsButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new ViewEventsPage("student", college, false);
            }
        });

        logoutButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
                new LoginPage();
            }
        });

        add(viewInCampusEventsButton);
        add(viewOutsideCampusEventsButton);
        add(logoutButton);

        setVisible(true);
    }
}
