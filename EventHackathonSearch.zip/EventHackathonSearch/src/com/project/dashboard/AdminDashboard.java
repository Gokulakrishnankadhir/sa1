package com.project.dashboard;

import com.project.auth.LoginPage;
import com.project.utils.DBConnection;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AdminDashboard extends JFrame {
    private JButton viewEventsButton;
    private JButton manageOrganizersButton;
    private JButton logoutButton;

    public AdminDashboard() {
        setTitle("Admin Dashboard");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new FlowLayout());

        // Initialize buttons
        viewEventsButton = new JButton("Manage All Events");
        manageOrganizersButton = new JButton("Approve Organizers");
        logoutButton = new JButton("Logout");

        // Event Listeners for buttons
        viewEventsButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                ViewEventsPage eventsPage = new ViewEventsPage("admin");
                eventsPage.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent windowEvent) {
                        setVisible(true);  // Show dashboard when ViewEventsPage closes
                    }
                });
                setVisible(false);  // Hide dashboard while managing events
            }
        });

        manageOrganizersButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                approveOrganizers();
            }
        });

        logoutButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int response = JOptionPane.showConfirmDialog(null, "Are you sure you want to logout?", "Confirm Logout", JOptionPane.YES_NO_OPTION);
                if (response == JOptionPane.YES_OPTION) {
                    dispose();
                    new LoginPage();
                }
            }
        });

        // Add buttons to the frame
        add(viewEventsButton);
        add(manageOrganizersButton);
        add(logoutButton);

        setVisible(true);
    }

    private void approveOrganizers() {
        try (Connection conn = DBConnection.getConnection()) {
            String query = "SELECT * FROM users WHERE role = 'organizer' AND approval_status = 'pending'";
            PreparedStatement stmt = conn.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();

            boolean approvalsMade = false;

            while (rs.next()) {
                int organizerId = rs.getInt("id");
                String organizerName = rs.getString("username");

                int response = JOptionPane.showConfirmDialog(null,
                    "Approve organizer: " + organizerName + "?", "Organizer Approval", JOptionPane.YES_NO_OPTION);

                if (response == JOptionPane.YES_OPTION) {
                    String approveQuery = "UPDATE users SET approval_status = 'approved' WHERE id = ?";
                    PreparedStatement approveStmt = conn.prepareStatement(approveQuery);
                    approveStmt.setInt(1, organizerId);
                    approveStmt.executeUpdate();
                    approvalsMade = true;
                }
            }

            if (approvalsMade) {
                JOptionPane.showMessageDialog(null, "Organizer approvals complete.");
            } else {
                JOptionPane.showMessageDialog(null, "No pending approvals found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error during organizer approval process.");
        }
    }
}
