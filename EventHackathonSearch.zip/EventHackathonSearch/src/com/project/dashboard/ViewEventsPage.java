package com.project.dashboard;

import com.project.services.EventService;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ViewEventsPage extends JFrame {
    private JTable eventsTable;
    private JButton addEventButton;
    private JButton editEventButton;
    private JButton deleteEventButton;
    private String role;
    private String college;
    private boolean inCampusOnly;

    public ViewEventsPage(String role) {
        this(role, null, true);
    }

    public ViewEventsPage(String role, String college) {
        this(role, college, true);
    }

    public ViewEventsPage(String role, String college, boolean inCampusOnly) {
        this.role = role;
        this.college = college;
        this.inCampusOnly = inCampusOnly;

        setTitle("Events");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Event table
        eventsTable = new JTable();
        refreshEventsTable();

        JScrollPane scrollPane = new JScrollPane(eventsTable);
        add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        addEventButton = new JButton("Add Event");
        editEventButton = new JButton("Edit Event");
        deleteEventButton = new JButton("Delete Event");

        if ("admin".equals(role) || "organizer".equals(role)) {
            buttonPanel.add(addEventButton);
            buttonPanel.add(editEventButton);
            buttonPanel.add(deleteEventButton);
        }

        add(buttonPanel, BorderLayout.SOUTH);

        addEventButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new AddEventPage(role, college, ViewEventsPage.this);
            }
        });

        editEventButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int selectedRow = eventsTable.getSelectedRow();
                if (selectedRow >= 0) {
                    int eventId = (int) eventsTable.getValueAt(selectedRow, 0);
                    new AddEventPage(role, college, ViewEventsPage.this, eventId);
                } else {
                    JOptionPane.showMessageDialog(null, "Please select an event to edit.");
                }
            }
        });

        deleteEventButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int selectedRow = eventsTable.getSelectedRow();
                if (selectedRow >= 0) {
                    int eventId = (int) eventsTable.getValueAt(selectedRow, 0);
                    EventService.deleteEvent(eventId);
                    refreshEventsTable();
                } else {
                    JOptionPane.showMessageDialog(null, "Please select an event to delete.");
                }
            }
        });

        setVisible(true);
    }

    public void refreshEventsTable() {
        eventsTable.setModel(EventService.getEvents(role, college, inCampusOnly));
    }
}
