package com.project.dashboard;

import com.project.services.EventService;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Date;

public class AddEventPage extends JFrame {
    private JTextField eventNameField;
    private JTextArea descriptionArea;
    private JTextField dateField;
    private JTextField locationField;
    private JButton saveButton;
    private int eventId = -1;
    private String role;
    private String college;
    private ViewEventsPage parentPage;

    public AddEventPage(String role, String college, ViewEventsPage parentPage) {
        this(role, college, parentPage, -1);
    }

    public AddEventPage(String role, String college, ViewEventsPage parentPage, int eventId) {
        this.role = role;
        this.college = college;
        this.parentPage = parentPage;
        this.eventId = eventId;

        setTitle(eventId > 0 ? "Edit Event" : "Add Event");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(6, 2));

        // Fields
        add(new JLabel("Event Name:"));
        eventNameField = new JTextField();
        add(eventNameField);

        add(new JLabel("Description:"));
        descriptionArea = new JTextArea();
        add(new JScrollPane(descriptionArea));

        add(new JLabel("Date (YYYY-MM-DD):"));
        dateField = new JTextField();
        add(dateField);

        add(new JLabel("Location:"));
        locationField = new JTextField();
        add(locationField);

        saveButton = new JButton(eventId > 0 ? "Update Event" : "Add Event");
        add(new JLabel()); // Empty cell for alignment
        add(saveButton);

        // Load event details if editing
        if (eventId > 0) {
            loadEventDetails(eventId);
        }

        saveButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String eventName = eventNameField.getText();
                String description = descriptionArea.getText();
                Date date = Date.valueOf(dateField.getText());
                String location = locationField.getText();

                if (eventId > 0) {
                    EventService.updateEvent(eventId, eventName, description, date, location);
                } else {
                    int createdBy = "admin".equals(role) ? 1 : -1; // Placeholder; ideally use logged-in user ID
                    EventService.addEvent(eventName, description, date, location, college, createdBy);
                }

                parentPage.refreshEventsTable();
                dispose();
            }
        });

        setVisible(true);
    }

    private void loadEventDetails(int eventId) {
        try {
            var event = EventService.getEventById(eventId);
            if (event != null) {
                eventNameField.setText(event.get("event_name").toString());
                descriptionArea.setText(event.get("event_description").toString());
                dateField.setText(event.get("event_date").toString());
                locationField.setText(event.get("location").toString());
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error loading event details.");
        }
    }
}
