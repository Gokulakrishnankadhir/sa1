package com.project.dashboard;

import com.project.utils.DBConnection;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class OrganizerDashboard extends JFrame {
    private String college;
    private JButton manageEventsButton;
    private JButton approveRegistrationsButton;
    private JButton logoutButton;

    public OrganizerDashboard(String college) {
        this.college = college;

        setTitle("Organizer Dashboard");
        setSize(400, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new FlowLayout());

        manageEventsButton = new JButton("Manage Events");
        approveRegistrationsButton = new JButton("Approve Registrations");
        logoutButton = new JButton("Logout");

        manageEventsButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new ViewEventsPage("organizer", college);
            }
        });

        approveRegistrationsButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                approveStudentRegistrations();
            }
        });

        logoutButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
                new LoginPage();
            }
        });

        add(manageEventsButton);
        add(approveRegistrationsButton);
        add(logoutButton);

        setVisible(true);
    }

    private void approveStudentRegistrations() {
        try (Connection conn = DBConnection.getConnection()) {
            String query = "SELECT * FROM registrations r JOIN users u ON r.user_id = u.id " +
                           "WHERE u.college = ? AND r.approval_status = 'pending'";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, college);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                int registrationId = rs.getInt("id");
                String studentName = rs.getString("username");

                int response = JOptionPane.showConfirmDialog(null, 
                    "Approve registration for student: " + studentName + "?", "Registration Approval", JOptionPane.YES_NO_OPTION);

                if (response == JOptionPane.YES_OPTION) {
                    String approveQuery = "UPDATE registrations SET approval_status = 'approved' WHERE id = ?";
                    PreparedStatement approveStmt = conn.prepareStatement(approveQuery);
                    approveStmt.setInt(1, registrationId);
                    approveStmt.executeUpdate();
                }
            }

            JOptionPane.showMessageDialog(null, "Student registration approvals complete.");
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error during student registration approval process.");
        }
    }
}
