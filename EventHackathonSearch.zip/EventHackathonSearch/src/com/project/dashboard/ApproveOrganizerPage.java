package com.project.dashboard;

import com.project.models.User;
import com.project.services.UserService;

import java.util.List;
import java.util.Scanner;

public class ApproveOrganizerPage {
    private UserService userService;

    public ApproveOrganizerPage() {
        this.userService = new UserService();
    }

    public void displayPendingOrganizers() {
        System.out.println("=== Approve New Organizers ===");

        List<User> pendingOrganizers = userService.getUsersByRole("organizer");
        boolean foundPending = false;

        for (User organizer : pendingOrganizers) {
            if (!organizer.isApproved()) {
                foundPending = true;
                System.out.println("Organizer Username: " + organizer.getUsername());
                System.out.println("College: " + organizer.getCollege());
                System.out.print("Approve this organizer? (y/n): ");
                Scanner scanner = new Scanner(System.in);
                String input = scanner.nextLine();

                if (input.equalsIgnoreCase("y")) {
                    boolean approvalSuccess = userService.approveOrganizer(organizer.getId());
                    if (approvalSuccess) {
                        System.out.println("Organizer approved successfully.");
                    } else {
                        System.out.println("Failed to approve organizer.");
                    }
                }
            }
        }

        if (!foundPending) {
            System.out.println("No pending organizers for approval.");
        }
    }
}
