package com.project.dashboard;

import com.project.services.RegistrationService;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ApproveRegistrationsPage extends JFrame {
    private JTable registrationsTable;
    private JButton approveButton;
    private JButton rejectButton;
    private String college;

    public ApproveRegistrationsPage(String college) {
        this.college = college;

        setTitle("Approve Registrations");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        registrationsTable = new JTable();
        refreshRegistrationsTable();

        JScrollPane scrollPane = new JScrollPane(registrationsTable);
        add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel();
        approveButton = new JButton("Approve");
        rejectButton = new JButton("Reject");

        approveButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                updateRegistrationStatus("approved");
            }
        });

        rejectButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                updateRegistrationStatus("rejected");
            }
        });

        buttonPanel.add(approveButton);
        buttonPanel.add(rejectButton);
        add(buttonPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    // Refreshes the table with pending registrations
    private void refreshRegistrationsTable() {
        registrationsTable.setModel(RegistrationService.getPendingRegistrations(college));
    }

    // Updates the selected registration's status
    private void updateRegistrationStatus(String status) {
        int selectedRow = registrationsTable.getSelectedRow();
        if (selectedRow >= 0) {
            int registrationId = (int) registrationsTable.getValueAt(selectedRow, 0);
            RegistrationService.updateRegistrationStatus(registrationId, status);
            refreshRegistrationsTable();
        } else {
            JOptionPane.showMessageDialog(null, "Please select a registration to update.");
        }
    }
}
