package com.project.dashboard;

import com.project.models.EventModel;
import com.project.services.EventService;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class ManageEventsPage {
    private EventService eventService;

    public ManageEventsPage() {
        this.eventService = new EventService();
    }

    public void displayEventManagementOptions() {
        Scanner scanner = new Scanner(System.in);
        boolean isRunning = true;

        while (isRunning) {
            System.out.println("\n=== Manage Events ===");
            System.out.println("1. View Pending Events");
            System.out.println("2. Update Event");
            System.out.println("3. Delete Event");
            System.out.println("4. Go Back");
            System.out.print("Choose an option: ");

            int choice = scanner.nextInt();
            switch (choice) {
                case 1:
                    viewPendingEvents();
                    break;
                case 2:
                    updateEvent();
                    break;
                case 3:
                    deleteEvent();
                    break;
                case 4:
                    isRunning = false;
                    break;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private void viewPendingEvents() {
        List<EventModel> pendingEvents = eventService.getEvents(null, "pending");
        
        if (pendingEvents.isEmpty()) {
            System.out.println("No pending events for approval.");
            return;
        }

        for (EventModel event : pendingEvents) {
            System.out.println("Event ID: " + event.getId());
            System.out.println("Event Name: " + event.getEventName());
            System.out.println("College: " + event.getCollege());
            System.out.print("Approve this event? (y/n): ");
            Scanner scanner = new Scanner(System.in);
            String input = scanner.nextLine();

            if (input.equalsIgnoreCase("y")) {
                boolean approvalSuccess = eventService.approveEvent(event.getId());
                System.out.println(approvalSuccess ? "Event approved." : "Failed to approve event.");
            }
        }
    }

    private void updateEvent() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter Event ID to update: ");
        int eventId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        System.out.print("Enter new event name: ");
        String eventName = scanner.nextLine();
        System.out.print("Enter new event description: ");
        String eventDescription = scanner.nextLine();
        System.out.print("Enter new event date (yyyy-MM-dd): ");
        String dateInput = scanner.nextLine();
        System.out.print("Enter new location: ");
        String location = scanner.nextLine();

        Date eventDate;
        try {
            eventDate = new SimpleDateFormat("yyyy-MM-dd").parse(dateInput);
        } catch (ParseException e) {
            System.out.println("Invalid date format. Please use yyyy-MM-dd.");
            return;
        }

        EventModel updatedEvent = new EventModel(eventId, eventName, eventDescription, eventDate, location, "", 0, "approved");
        boolean updateSuccess = eventService.updateEvent(updatedEvent);

        System.out.println(updateSuccess ? "Event updated successfully." : "Failed to update event.");
    }

    private void deleteEvent() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter Event ID to delete: ");
        int eventId = scanner.nextInt();

        boolean deleteSuccess = eventService.deleteEvent(eventId);
        System.out.println(deleteSuccess ? "Event deleted successfully." : "Failed to delete event.");
    }
}
